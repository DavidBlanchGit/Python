"""Autor : Daniel Alonso
Fecha : 18/10/2020
Python version : 3.8
Descripción : Este es un programa de cálculo de
un números pares. A continuación se pedirá un
número y se calculará el número de pares desde
0 hasta ese número."""

# Esto pide un número al usuario
num_limite = int(input("¿Hasta que número quiere calcular pares? "))

# Cálculo de pares
contador = 0
for num in range(num_limite + 1):
    if num % 2 == 0:
        contador += 1

# Resultado final
print("Entre 0 y", num_limite, "hay", contador, "números pares.")
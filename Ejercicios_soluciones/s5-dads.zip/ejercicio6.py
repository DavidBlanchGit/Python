"""Autor : Daniel Alonso
Fecha : 18/10/2020
Python version : 3.8
Descripción : Este es un programa de impresión
de números no primos . A continuación se imprimirán
todos los números no primos hasta 30."""

# Esta variable define si es primo o no
es_primo = True

# Comprobamos todos los números entre 0 y 30
for num in range(31):

    # El cero y el uno no son primos
    if num == 0 or num == 1:
        print(num)

    #Esto comprueba si un número es primo
    for div in range(1, num):

        # Si es divisible por un número que no sea 1
        # o el propio número, no es primo
        if div != 1 and div != num:
            if num % div == 0:
                es_primo = False

    # Si no es primo se imprime el número
    if not es_primo:
        print(num)
        es_primo = True
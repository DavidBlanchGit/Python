"""Autor : Daniel Alonso
Fecha : 18/10/2020
Python version : 3.8
Descripción : Este es un programa de generación de
un número aleatorio. A continuación se generará un
número y el usuario tendrá que acertarlo."""

# Esto importa la librería random
import random

# Esto genera el número
numero = random.randint(1, 20)

# Presentación del programa
print("\nPROGRAMA AVERIGUACIÓN NUMERO ALEATORIO"
      "\n--------------------------------------"
      "\nSe generará un número aleatorio entre 1 y 20."
      "\nTrate de acertarlo.")

# Esto pide al usuario un número
num_usuario = int(input("Introduce un número: "))

# Esto dará pistas al usuario si no acierta
while num_usuario != numero:

    # Si pone un número no válido
    if num_usuario not in range(1,21):
        print("El número debe estar entre 1 y 20.")
        num_usuario = int(input("\nIntroduce un número: "))

    # Si pone un número menor
    elif num_usuario < numero:
        print("El número es mayor que", str(num_usuario) + ".")
        num_usuario = int(input("\nIntroduce un número: "))

    # Si pone un número mayor
    elif num_usuario > numero:
        print("El número es menor que", str(num_usuario) + ".")
        num_usuario = int(input("\nIntroduce un número: "))

# Cuando el usuario acierta
print("\nFelicidades, el número buscado era:", numero)
"""Autor : Daniel Alonso
Fecha : 18/10/2020
Python version : 3.8
Descripción : Este es un programa de averiguación
de números. A continuación se pedirán una serie de
datos al usuario y se tratará de averiguar un número."""

# Variable que determina si es mayor/menor/igual a 5
may_men = input("El número ¿es mayor o menor de 5? (igual/mayor/menor) ")
while may_men != "igual" and may_men != "mayor" and may_men != "menor":
    print("Comando no válido\n")
    may_men = input("El número ¿es mayor o menor de 5? (igual/mayor/menor) ")
if may_men == "igual":
    print("5")
elif may_men == "menor":
    for num in range(1, 5):
        print(num, end = " ")
elif may_men == "mayor":
    for num in range(6, 11):
        print(num, end = " ")

# Variable que determina si es par o impar
par_imp = input("\n¿Es par o impar? (par/impar) ")
while par_imp != "par" and par_imp != "impar":
    print("Comando no válido")
    par_imp = input("\n¿Es par o impar? (par/impar) ")
if may_men == "igual":
    print("5")
elif may_men == "menor" and par_imp == "par":
    for num in range(2, 5, 2):
        print(num, end = " ")
elif may_men == "menor" and par_imp == "impar":
    for num in range(1, 5, 2):
        print(num, end = " ")
elif may_men == "mayor" and par_imp == "par":
    for num in range(6, 11, 2):
            print(num, end=" ")
elif may_men == "mayor" and par_imp == "impar":
    for num in range(7, 11, 2):
        print(num, end = " ")

# Variable que determina estremo superior/inferior o centro
sup_inf = input("\n¿Extremo superior o inferior? (centro/superior/inferior) ")
while sup_inf != "superior" and sup_inf != "centro" and sup_inf != "inferior":
    print("Comando no válido")
    sup_inf = input("\n¿Extremo superior o inferior? (centro/superior/inferior) ")
if may_men == "igual":
    print("5")
elif may_men == "menor" and par_imp == "par" and sup_inf == "inferior":
    print("2")
elif may_men == "menor" and par_imp == "par" and sup_inf == "superior":
    print("4")
elif may_men == "menor" and par_imp == "impar" and sup_inf == "inferior":
    print("1")
elif may_men == "menor" and par_imp == "impar" and sup_inf == "superior":
    print("3")
elif may_men == "mayor" and par_imp == "par" and sup_inf == "inferior":
    print("6")
elif may_men == "mayor" and par_imp == "par" and sup_inf == "superior":
    print("10")
elif may_men == "mayor" and par_imp == "par" and sup_inf == "centro":
    print("8")
elif may_men == "mayor" and par_imp == "impar" and sup_inf == "inferior":
    print("7")
elif may_men == "mayor" and par_imp == "impar" and sup_inf == "superior":
    print("9")
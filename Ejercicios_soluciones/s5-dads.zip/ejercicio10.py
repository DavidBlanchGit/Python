"""Autor : Daniel Alonso
Fecha : 18/10/2020
Python version : 3.8
Descripción : Este es un programa de verificación
de números. A continuación se pedirán una entrada
y se verificará si es número o no. Después se
imprimirá su cuadrado"""

# Variable que determina si es número
es_numero = False
cadena = ""

# Se repite hasta que sea número
while not es_numero:
    cadena = input("Introcuce un número: ")

# Comprobar si es entero
    if cadena.isdigit():
        es_numero = True

# Comprobar si es string o flotante
    else:
        es_flotante = True
        puntos = 0
        for caracter in cadena:
            if caracter == ".":
               puntos += 1
            elif not caracter.isdigit():
                es_flotante = False
        if es_flotante and puntos <= 1:
            es_numero = True
        else:
            es_numero = False

# Esto imprime el cuadrado
if es_numero:
    cuadrado = float(cadena) ** 2
    print("El cuadrado de", cadena, "es:", cuadrado)
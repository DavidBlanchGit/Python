"""Autor : Daniel Alonso
Fecha : 18/10/2020
Python version : 3.8
Descripción : Este es un programa de multiplicación
de dos números. A continuación se pedirán dos
números y se multiplicarán usando solo sumas."""

# Esto pide dos número al usuario
num1 = int(input("Introduzca un número entero: "))
num2 = int(input("Introduzca otro número entero: "))

# Multiplicación mediante sumas
mult = 0
for num in range(num2):
    mult += num1

# Resultado final
print("El resultado de multiplicar", num1, "y", num2, "es:", mult)
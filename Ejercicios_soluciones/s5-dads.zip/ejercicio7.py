"""Autor : Daniel Alonso
Fecha : 18/10/2020
Python version : 3.8
Descripción : Este es un programa de generación
de números aleatorios. A continuación se pedirán
al usuario 2 números enteros A y B tales que
A + 5 < B. Después se calcularán 5 números aleatorios
entre A y B, respetando la alternancia par-impar."""

# Esto importa la librería random
import random

# Número inicial del usuario
a = int(input("Introduce un número entero: "))

# Segundo número de la forma B >= A + 5
b = int(input("Introduce un número entero mayor o igual que " + str(a + 5) + ": "))
while b < a + 5:
    print("Número no válido.")
    b = int(input("\nIntroduce un número entero mayor o igual que " + str(a + 5) + ": "))

# Generación 5 números par-impar
num1 = random.randrange(a, b + 1, 2)
num2 = random.randrange(a + 1, b + 1, 2)
num3 = random.randrange(a, b + 1, 2)
num4 = random.randrange(a + 1, b + 1, 2)
num5 = random.randrange(a, b + 1, 2)

# Impresión números
print(num1, num2, num3, num4, num5)
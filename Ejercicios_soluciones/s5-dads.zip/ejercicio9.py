"""Autor : Daniel Alonso
Fecha : 18/10/2020
Python version : 3.8
Descripción : Este es un programa de generación
de números perfectos. A continuación se pedirá un
número límite y se calcularán los números perfectos
hasta ese número."""

# Variable que indica el límite
num_final = int(input("¿Hasta qué número quiere calcular perfectos? "))

# Cálculo de números perfectos
for num in range(1, num_final + 1):
    suma = 0
    for div in range(1, num):
        if num % div == 0:
            suma += div
    if num == suma:
        print("El número", num, "es perfecto.")
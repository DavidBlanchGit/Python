"""Autor : Daniel Alonso
Fecha : 18/10/2020
Python version : 3.8
Descripción : Este es un programa de generación de
un código PIN. A continuación se generará un código
y el usuario tendrá 3 intentos para acertarlo."""

# Esto importa la librería random
import random

# Esto genera una cantidad de dinero aleatoria
saldo = round(random.uniform(50, 5000), 2)

# Esto genera un número PIN aleatorio
pin = ""
for numero in range(4):
    pin += str(random.randint(0, 9))

# Esto solicita al usuario el código PIN
pin_ususario = input("Introduce un pin de 4 cifras: ")
contador = 1

# El usuario tiene 3 intentos
while contador < 3 and pin_ususario != pin:
    print("PIN incorrecto. Queda(n)", 3 - contador,"intento(s).\n")
    pin_ususario = input("Introduce un pin de 4 cifras: ")
    contador += 1

# Esto comprueba que el pin sea correcto
if pin_ususario == pin:
    print("El código PIN es correcto.")
else:
    print("El código PIN es incorrecto. Ha agotado sus intentos.")
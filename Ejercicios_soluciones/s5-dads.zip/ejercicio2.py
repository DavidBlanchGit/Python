"""Autor : Daniel Alonso
Fecha : 18/10/2020
Python version : 3.8
Descripción : Este programa es continuación del
anterior. A continuación se generará un código
y el usuario tendrá 3 intentos para acertarlo."""

# Esto importa la librería random
import random

# Esto genera una cantidad de dinero aleatoria
saldo = round(random.uniform(50, 5000), 2)

# Esto genera un número PIN aleatorio
pin = ""
for numero in range(4):
    pin += str(random.randint(0, 9))
print(pin, saldo)
# Esto solicita al usuario el código PIN
pin_ususario = input("Introduce un pin de 4 cifras: ")
contador = 1

# El usuario tiene 3 intentos
while contador < 3 and pin_ususario != pin:
    print("PIN incorrecto. Queda(n)", 3 - contador, "intento(s).\n")
    pin_ususario = input("Introduce un pin de 4 cifras: ")
    contador += 1

# Esto comprueba que el pin sea correcto
if pin_ususario != pin:
    print("El código PIN es incorrecto. Ha agotado sus intentos.")
else:
    print("""El código PIN es correcto.
Bienvenido.
------------------------
1- Ingreso efectivo
2- Retirada efectivo
3- Salir""")

    # Esto sirve para indicar la operación
    operacion = input("Indique la operación a realizar: ")
    while operacion != "1" and operacion != "2" and operacion != "3":
        print("Operación no válida.\n")
        operacion = input("Indique la operación a realizar: ")

    # Esto es para ingresar dinero
    if operacion == "1":
        print('\nHa seleccionado "Ingreso de efectivo".')
        cantidad = float(input("Indique la cantidad de dinero que desea ingresar: "))
        saldo += round(cantidad, 2)

    # Esto es para retirar dinero
    elif operacion == "2":
        print('\nHa seleccionado "Retirada de efectivo".')
        cantidad = float(input("Indique la cantidad de dinero que desea retirar: "))
        while cantidad > saldo:
            print("Cantidad no válida. Su saldo es de", saldo, "euros.\n")
            cantidad = float(input("Indique la cantidad de dinero que desea retirar: "))
        saldo -= round(cantidad, 2)

    # Esto es para salir
    else:
        print('\nHa seleccionado "Salir".')

    # Esto nos indica el saldo antes de finalizar el programa
    print("Su saldo actual es de", saldo, "euros.")
    print("\nOperaciones realizadas, que tenga un buen día.")
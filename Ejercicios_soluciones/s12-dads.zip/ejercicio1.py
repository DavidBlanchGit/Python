"""Autor : Daniel Alonso
Fecha : 05/12/2020
Python version : 3.8
Descripción : Este es un programa de definición de clases.
A continuación se creará una clase Persona con varios
atributos y se realizarán operaciones con ella."""


# Creamos la clase
class Persona:
    def __init__(self, nombre: str, edad: int, dni: int, peso=90.0,
                 altura=185.0, sexo='mujer'):
        """Esta función inicia un objeto con los parametros introducidos,
        añadiendolos a los atributos de la clase.
        @param nombre: str
        @param edad: int
        @param dni: int
        @param peso: float
        @param altura: float
        @param sexo: str"""

        self.nombre = nombre
        self.edad = edad

        # Comproobamos que sea válido el DNI
        if len(str(dni)) in range(1, 9):
            self.num_dni = dni
        else:
            self.num_dni = 10000000

        self.peso = peso
        self.altura = altura
        self.sexo = sexo
        self.letra_dni = self.__calcular_letra_dni()
        self.dni = str(self.num_dni) + '-' + self.letra_dni

    def __calcular_letra_dni(self):
        """Esta función calcula la letra del DNI dividiendo su valor por 23
        y asignando una letra de la variable letras que se muestra a
        continuación.
        @return: str"""

        letras = 'TRWAGMYFPDXBNJZSQVHLCKE'
        indice = self.num_dni % 23

        return letras[indice]

    def __str__(self):
        """Esta función devuelve una cadena de texto con los parámetros
        introducidos cuando se intenta imprimir un objeto.
        @return: str"""

        datos = ('Información personal:\nNombre: %s \nSexo: %s \nEdad: %i años'
                 '\nDNI: %s \nPeso: %.1f kg \nAltura: %.1f cm' %
                 (self.nombre, self.sexo, self.edad, self.dni,
                  self.peso, self.altura))

        return datos


# Pedimos los datos por teclado
nombre1 = input("Introduce el nombre de la primera persona: ").capitalize()
edad1 = int(input("Introduce su edad: "))
dni1 = int(input("Introduce su número de DNI: "))
peso1 = int(input("Introduce su peso: "))
altura1 = int(input("Introduce su altura: "))
sexo1 = input("Introduce su sexo: ").lower()
nombre2 = input("Introduce el nombre de la segunda persona: ").capitalize()
edad2 = int(input("Introduce su edad: "))
dni2 = int(input("Introduce su número de DNI: "))

# Tupla con objetos de Persona
tupla = (Persona('Daniel', 18, 54303664, 78.4, 191, 'hombre'),
         Persona(nombre1, edad1, dni1, peso1, altura1, sexo1),
         Persona(nombre2, edad2, dni2))

# Imprimimos el resultado
for objeto in tupla:
    print('')
    print(objeto)

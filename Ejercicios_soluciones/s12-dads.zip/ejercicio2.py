"""Autor : Daniel Alonso
Fecha : 05/12/2020
Python version : 3.8
Descripción : Este es un programa de definición de clases.
A continuación se creará una clase Rectángulo y se realizarán
operaciones con ella."""

# Importamos la librería random
import random


# Creamos la clase
class Rectangulo:
    def __init__(self, base: float, altura=None):
        """Esta función inicia un objeto con los parametros introducidos,
        añadiendolos a los atributos de la clase.
        @param base: float
        @param altura: float"""

        self.base = base
        if altura is None:
            self.altura = base
        else:
            self.altura = altura

    # Propiedad y setter de la base
    @property
    def base(self) -> float:
        return self.__base

    @base.setter
    def base(self, base: float):
        if base > 0:
            self.__base = base
        else:
            self.__base = 1

    # Propiedad y setter de la altura
    @property
    def altura(self) -> float:
        return self.__altura

    @altura.setter
    def altura(self, altura: float):
        if altura > 0:
            self.__altura = altura
        else:
            self.__altura = 1

    # Propiedad de cuadrado
    @property
    def cuadrado(self) -> bool:
        """Esta propiedad devuelve True si el rectángulo es también un cuadrado
        y False si no lo es.
        @return: bool"""

        return self.base == self.altura

    def __str__(self):
        """Esta función devuelve una cadena de texto con los parámetros
        introducidos cuando se intenta imprimir un objeto.
        @return: str"""

        cuad_rect = 'cuadrado' if self.cuadrado else 'rectángulo'

        resultado = 'Un %s de base %.2f y altura %.2f.' % \
                    (cuad_rect, self.base, self.altura)

        return resultado

    def __eq__(self, other):
        """Esta función comprueba si dos clases son iguales en parámetros. Si
        la base y la altura están alternadas lo contará como igual.
        @return: bool"""

        return (self.altura == other.altura and self.base == other.base) or \
               (self.altura == other.base and self.base == other.altura)

    def perimetro(self):
        """Esta función calcula el perímetro de un determinado objeto de
        la clase Rectangulo cuando es llamado.
        @return: float"""

        return 2 * self.base + 2 * self.altura

    def area(self):
        """Esta función calcula el área de un determinado objeto de
        la clase Rectangulo cuando es llamado.
        @return: float"""

        return self.base * self.altura

    def lado_mayor(self):
        """Esta función calcula el lado mayor de un determinado objeto de
        la clase Rectangulo cuando es llamado.
        @return: float"""

        return max(self.base, self.altura)

    def rectangulo_a_cuadrado(self):
        """Esta función convierte un rectángulo en un cuadrado de lado el
        valor máximo entre la altura y la base. Devuelve True si lo que
        cambia es la base y False si cambia la altura.
        @return: boolean"""

        if self.altura > self.base:
            self.base = self.altura
            cambio = True

        else:
            self.altura = self.base
            cambio = False

        return cambio


# Creamos una lista con un número aleatorio de objetos de la clase Rectangulo
lista_rectan = []
for n in range(random.randint(10, 1000)):
    bases = random.randint(1, 10)
    alturas = random.randint(1, 10)
    lista_rectan.append(Rectangulo(bases, alturas))

# Comprobamos los que son cuadrados
print("Rectángulos cuadrados:")
lista_cuadrados = []
for objeto in lista_rectan:
    if objeto.cuadrado and objeto not in lista_cuadrados:
        lista_cuadrados.append(objeto)
        print(objeto)

# Calculamos el de mayor área
print("\nLos de máxima área:")
lista_area, lista_max_area = [], []
for objeto in lista_rectan:
    lista_area.append(objeto.area())
max_area = max(lista_area)
for objeto in lista_rectan:
    if objeto.area() == max_area and objeto not in lista_max_area:
        lista_max_area.append(objeto)
        print(objeto)

# Calculamos el de mayor perímetro
print("\nLos de máximo perímetro:")
lista_perimetro, lista_max_perim = [], []
for objeto in lista_rectan:
    lista_perimetro.append(objeto.perimetro())
max_perimetro = max(lista_perimetro)
for objeto in lista_rectan:
    if objeto.perimetro() == max_perimetro and objeto not in lista_max_perim:
        lista_max_perim.append(objeto)
        print(objeto)

# Calculamos el de lado más grande
print("\nLos de lado mas grande:")
lista_lado, lista_max_lado = [], []
for objeto in lista_rectan:
    lista_lado.append(objeto.lado_mayor())
max_lado = max(lista_lado)
for objeto in lista_rectan:
    if objeto.lado_mayor() == max_lado and objeto not in lista_max_lado:
        lista_max_lado.append(objeto)
        print(objeto)

# Convertir a cuadrados los de mayor lado
print("\nLos de lado mas grande pasan a ser cuadrados:")
for objeto in lista_max_lado:
    if not objeto.cuadrado:
        print(objeto)
        a_b = objeto.rectangulo_a_cuadrado()

        if a_b:
            cambio2 = 'base'
        else:
            cambio2 = 'altura'

        print('Cambia la', cambio2, 'para ser un cuadrado de lado',
              objeto.lado_mayor())

"""Autor : Daniel Alonso
Fecha : 04/10/2020
Python version : 3.8
Descripción : Este es un programa de resta de variables.
A continuación se declararán dos variables de tipo float
y se restarán. Posteriormente se hará lo mismo con dos
variables de tipo int."""

# Esto resta las dos variables de tipo float
var1 = 12345678901234567.0
var2 = 12345678901234568.0
print(var1 - var2)

# Esto resta las dos variables de tipo int
var1 = 12345678901234567
var2 = 12345678901234568
print(var1 - var2)

"""Mientras que la primera resta nos da 0.0, la segunda 
nos devuelve -1, que es el valor real de la resta. Esto 
se debe a que cuando se usa una variable de tipo float 
Python solo guarda las primeras 15 o 16 cifras, el resto
las redondea; por lo que, en este caso, ambas variables 
valen lo mismo. Sin embargo, con los números enteros no 
ocurre esto, ya que solo tienen como límite la memoria
del ordenador, por lo que pueden llegar a ser prácticamente 
infinito"""
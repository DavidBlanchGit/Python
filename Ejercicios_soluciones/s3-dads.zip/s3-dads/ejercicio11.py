"""Autor : Daniel Alonso
Fecha : 04/10/2020
Python version : 3.8
Descripción : Este es un programa de impresión de
variables. Se asigará una variable de tipo str y se
imprimirán partes de ella"""

# Esto imprime la cadena
var1 = """¡Hola don Pepito! \n\t¡Hola don José! 
¿Pasó usted por mi casa? \n\t\tPor su casa yo pasé. 
¿Vio usted a mi abuela? \n\t\t\tA su abuela yo la vi."""

# Esto selecciona partes de la cadena y las imprime
var2 = var1[:17]
var3 = var1[20:35]
var4 = var1[-21:]
print(var2, var3, var4)
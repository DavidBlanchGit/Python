"""Autor : Daniel Alonso
Fecha : 04/10/2020
Python version : 3.8
Descripción : Este es un programa de división por cero.
A continuación se declararán tres variables: un número
entero, 0 y la división de ambas. Posteriormente se
imprimirá la tercera variable"""

# Esto imprime el valor de la división
var1, var2 = 5, 0
var3 = var1 / var2
print(var3)

# Esto hace lo mismo pero con flotantes
var1, var2 = 5.0, 0.0
var3 = var1 / var2
print(var3)

"""Al intentar realizar la primera división nos devuelve
ZeroDivisionError debido a que no se puede dividir por 
cero. Al intentarlo con flotantes ocurre lo mismo."""
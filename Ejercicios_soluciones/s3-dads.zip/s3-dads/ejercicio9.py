"""Autor : Daniel Alonso
Fecha : 04/10/2020
Python version : 3.8
Descripción : Este es un programa de concatenación de
texto. A continuación se declararán tres variables: dos
cadenas de texto y la suma de ambas. Posteriormente se
imprimirá la tercera variable. Se hará lo mismo
con la resta."""

# Esto imprime el valor de la suma
var1, var2 = "Hola ", "mundo"
var3 = var1 + var2
print(var3)

# Esto imprime el valor de la resta
var3 = var1 - var2
print(var3)

"""Al intentar realizar la primera suma nos devuelve
la concatenación de las dos cadenas. Sin embargo, al
intentar restar nos devuelve un error de comando inválido"""
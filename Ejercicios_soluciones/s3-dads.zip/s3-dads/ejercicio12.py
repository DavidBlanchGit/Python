"""Autor : Daniel Alonso
Fecha : 04/10/2020
Python version : 3.8
Descripción : Este es un programa de impresión con
formato. Se asigarán variables y se imprimirán en
cadenas de texto."""

# Código facilitado en el documento
nombre = 'Johnny Depp'
edad = 55
altura = 1.78
peso = 65.8
ojos = 'marrones'
pelo = 'castaño'
print("Hablemos de %s." % nombre)
print("Tiene %i años." % edad)
print("Mide %.2f metros." % altura)
print("Pesa %.0f kilogramos." % peso)
print("De hecho no está nada gordo.")
print("Tiene ojos %s y pelo %s." % (ojos, pelo))

# Modificación del código anterior
print("Hablemos de", nombre + ".")
print("Tiene", edad, "años.")
print("Mide", altura, "metros.")
print("Pesa", peso, "kilogramos.")
print("De hecho no está nada gordo.")
print("Tiene ojos", ojos, "y pelo", pelo + ".")

"""La principal diferencia es que en en el primer
método redondea el peso a las unidades. Además, el
sefundo método es mucho más tedioso cuando hay 
muchas variables o se encuentran en medio."""

"""Autor : Daniel Alonso
Fecha : 04/10/2020
Python version : 3.8
Descripción : Este es un programa de inicialización de
variables. A continuación se declararán tres variables
de distinto tipo en una misma línea y se imprimirán"""

# Esto inicializa 3 variables de distinto tipo en una línea
var1, var2, var3 = 24, "hola", True
print(var1, var2, var3)

"""Como hemos visto en el programa, es posible inicializar
tres variables de tipo distinto en una sola línea"""
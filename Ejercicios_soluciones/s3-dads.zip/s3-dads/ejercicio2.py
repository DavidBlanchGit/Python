"""Autor : Daniel Alonso
Fecha : 04/10/2020
Python version : 3.8
Descripción : Este es un programa de uso de variables no inicializadas.
A continuación se declarará una variable sin inicializarla y se imprimirá."""

# Esto es una variable no inicializada
var1 =

# Esto imprime la variable
print(var1)

"""Imprimir una variable no inicializada nos devuelve un error, 
en este caso : SyntaxError. Esto ocurre porque no le hemos asignado
un valor previo."""
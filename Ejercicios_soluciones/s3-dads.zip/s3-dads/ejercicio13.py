"""Autor : Daniel Alonso
Fecha : 04/10/2020
Python version : 3.8
Descripción : Este es un programa de impresión de
números fuera de rango. Primero se multiplicarán
dos números muy grandes y después se elevarán."""

# Esto multiplica dos números muy grandes
var1 = 1.0E+308
var2 = 2.2E+307
var3 = var1 * var2
print(var3)

# Esto eleva al cuadrado dos números muy grandes
var4, var5 = var1**2, var2**2
print(var4, var5)

"""Mientas que la primera multiplicación nos devuelve
inf por ser un valor que sobrepasa el límite, las 
potencias nos devuelven OverflowError"""
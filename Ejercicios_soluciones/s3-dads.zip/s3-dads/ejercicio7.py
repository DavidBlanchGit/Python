"""Autor : Daniel Alonso
Fecha : 04/10/2020
Python version : 3.8
Descripción : Este es un programa de copia de variables.
A continuación se declararán dos variables de tipo float
y se igualará la segunda a la primera. Posteriormente se
le cambiará el valor a la primera y se imprimirá la
segunda."""

# Esto copia el valor de la primera variable en la segunda
var1 = 20.2
var2 = var1
print(var2)

# Esto cambia el valor de la primera variable
var1 = 123.5
print(var2)

"""Al cambiar el valor de la primera variable, no lo hace
la segunda, para ello tendríamos que indicarlo de nuevo, 
pues el cambio es posterior a la copia del valor."""
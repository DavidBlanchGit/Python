"""Autor : Daniel Alonso
Fecha : 04/10/2020
Python version : 3.8
Descripción : Este es un programa de impresión de una
variable. Se asigará un valor de tipo str y se le
añadirán saltos de línea y tabulaciones."""

# Esto imprime la cadena
var1 = """¡Hola don Pepito! \n\t¡Hola don José! 
¿Pasó usted por mi casa? \n\t\tPor su casa yo pasé. 
¿Vio usted a mi abuela? \n\t\t\tA su abuela yo la vi."""
print(var1)


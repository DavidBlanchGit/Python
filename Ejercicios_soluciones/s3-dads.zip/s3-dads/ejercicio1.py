"""Autor : Daniel Alonso
Fecha : 04/10/2020
Python version : 3.8
Descripción : Este es un programa de declaración de variables.
A continuación se declarará una variable de cada tipo."""

# Esto es una variable de tipo : int
var1 = 20

# Esto es una variable de tipo : float
var2 = 20.19

# Esto es una variable de tipo : complex
var3 = 5 + 2j

# Esto es una variable de tipo : str
var4 = "Hola mundo"

# Esto es una variable de tipo : bool
var5 = True

"""La característica de python que hace que no necesitemos
escribir el tipo de variable se llama : tipado dinámico."""
"""Autor : Daniel Alonso
Fecha : 04/10/2020
Python version : 3.8
Descripción : Este es un programa de cambio de valor de
una variable. A continuación se declarará una variable
con un valor inicial y posteriormente se le cambiará."""

# Este es el valor inicial de la variable
var1 = 28
print(var1)

# Esto cambia el valor de la variable
var1 = 98
print(var1)

"""Como su nombre indica, es posible cambiar el valor 
de una variable. Además, en python se puede cabiar el tipo
de la variable, aunque no es recomendable."""
"""Autor : Daniel Alonso
Fecha : 04/10/2020
Python version : 3.8
Descripción : Este es un programa de cambio de tipo de
una variable. A continuación se declarará una variable
con un valor entero inicial y posteriormente se le cambiará
a un valor de tipo string."""

# Este es el valor inicial de la variable
var1 = 28
print(var1)

# Esto cambia el tipo y valor de la variable
var1 = "hola"
print(var1)

"""Como se muestra en el programa, en python podemos cambiar 
el tipo de una variable asignándole un valor de tipo distinto.
Sin embargo, no es recomendable. Esta propiedad se llama : 
tipo dinámico"""
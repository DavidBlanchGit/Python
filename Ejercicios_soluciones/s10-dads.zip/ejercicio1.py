"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de funciones.
A continuación se creará una función que sumule el funcionamiento
de la función range()."""


# Creamos la función
# Iniciamos la variable step en 1, lo que hace que no sea necesario añadirla
def my_range(start=0, stop=None, step=1):
    """Esta es una función que simula el funcionamiento de la función range().
    @param start: int
    @param stop: int
    @param step: int
    @return: tuple"""

    # En caso de que solo se introduzca una variable, deberá asignarse a 'stop'
    # y no a 'start'
    if stop == None:
        stop = start
        start = 0

    # Variable que guarda los números que estan en el rango
    range_list = []

    # Solo se ejecutará el bucle si las variables son de tipo int
    if isinstance(start, int) and isinstance(stop, int) and \
            isinstance(step, int):

        # Bucle que calcula los números de dicho rango
        while start < stop:
            range_list.append(start)
            start += step

    # Conversión a tupla
    range_tuple = tuple(range_list)

    return range_tuple


# Mostramos el resultado
print(my_range(5))
print(my_range(1, 10))
print(my_range(1, 10, 2))

"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de funciones.
A continuación se crearán dos funciones: la primera devolverá las
posiciones en las que aprarece un elemento en una lista y la segunda
devolverá las posiciones en común de un elemento en dos listas."""


# Primera función
def posiciones(list1: list, x):
    """Esta función devuelve las posiciónes en las que aparece un elemento
    en una lista. Si no se encuentra en la lista devolverá una tupla vacía.
    Tanto el elemento como la lista se darán como parámetros.
    @param list1: list
    @param x: Any
    @return: tuple"""

    # Creamos una variable que contenga la posición del elemento
    contador = 0

    # Creamos también la variable que devolveremos con las posiciones
    posicion = []

    # Recorremos la lista dada como parámetro
    for elemento in list1:

        # Si el elemento es el buscado se guarda su posición
        if elemento == x:
            posicion.append(contador)

        contador += 1

    # Conversión a tupla
    posicion = tuple(posicion)

    # Devolvemos las posiciones
    return posicion


# Segunda función
def posiciones_comunes(list1: list, list2: list, x):
    """Esta función devuelve las posiciónes comunes que tiene un elemento en
    dos listas. Tanto el elemento como las listas se darán como parámetros.
    @param list1: list
    @param list2: list
    @param x: Any
    @return: tuple"""

    # Iniciamos dos variables con las posiciones del elemento en cada lista
    pos1 = posiciones(list1, x)
    pos2 = posiciones(list2, x)

    # Iniciamos una variable que guarde las posiciones comunes
    pos_comunes = []

    # Recorremos la primera tupla
    for elemento in pos1:

        # Si el elemento se encuentra también en la otra tupla, lo guarda
        if elemento in pos2:
            pos_comunes.append(elemento)

    # Conversión a tupla
    pos_comunes = tuple(pos_comunes)

    # Devolvemos la tupla
    return pos_comunes


# Mostramos el resultado
lista1 = [1, 2, 1, 3, 1, 4, 1, 5]
lista2 = [1, 2, 3, 1, 4, 5, 1, 6]
print(posiciones(lista1, 1), posiciones(lista2, 1))
print(posiciones_comunes(lista1, lista2, 1))

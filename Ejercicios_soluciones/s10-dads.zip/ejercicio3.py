"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de funciones.
A continuación se crearán funciones que simulen el comportamiento
de los métodos de listas."""


# Función count()
def count(list1: list, x):
    """Esta función devuelve el número de veces que aparece un elemento en una
    lista. Tanto el elemento como la lista se darán como parámetros.
    @param list1: list
    @param x: Any
    @return: int"""

    # Creamos la variable que contará las veces que aparece
    contador = 0

    # Recorremos la lista dada como parámetro
    for elemento in list1:

        # Si el elemento coincide con el buscado, el contador aumenta 1
        if elemento == x:
            contador += 1

    # Devolvemos el valor de contador
    return contador


# Función index()
def index(list1: list, x):
    """Esta función devuelve la posición en la que aparece un elemento por
    primera vez en una lista. Si no se encuentra en la lista devolverá None.
    Tanto el elemento como la lista se darán como parámetros.
    @param list1: list
    @param x: Any
    @return: int or None"""

    # Creamos una variable que contenga la posición del elemento y otra que
    # nos diga si se ha encontrado el elemento buscado
    contador = 0
    encontrado = False

    # Creamos también la variable que devolveremos con la posición
    posicion = None

    # Recorremos la lista dada como parámetro
    for elemento in list1:

        # Si el elemento es el buscado y es la primera vez que se encuentra,
        # se guarda su posición
        if elemento == x and not encontrado:
            posicion = contador
            encontrado = True

        contador += 1

    # Devolvemos la posición. En caso de no haberlo encontrado devuelve None.
    return posicion


# Función append()
def append(list1: list, x):
    """Esta función añade un elemento en la última posición de una lista.
    Tanto el elemento como la lista se darán como parámetros. No devuelve nada.
    @param list1: list
    @param x: Any"""

    # Añadimos el elemento usando el símbolo de suma
    list1 += [x]


# Función find()
def find(list1: list, x):
    """Esta función devuelve un booleano indicando si encontró un elemento o no
    en una lista. Tanto el elemento como la lista se darán como parámetros.
    @param list1: list
    @param x: any
    @return: bool"""

    # Creamos una variable que nos diga si se ha encontrado el elemento buscado
    encontrado = False

    # Recorremos la lista dada como parámetro
    for elemento in list1:

        # Si el elemento es el buscado encontrado pasa a ser True
        if elemento == x:
            encontrado = True

    # Devolvemos el valor True o False de la variable encontrado
    return encontrado


# Función insert
def insert(list1: list, x, pos: int):
    """Esta función añade un elemento en una determinada posición de una lista.
    Tanto el elemento, como la lista y la posición se darán como parámetros.
    @param list1: list
    @param pos: int
    @param x: Any
    @return: list"""

    # Añadimos el elemento usando el símbolo de suma
    list1 = list1[:pos] + [x] + list1[pos:]

    # Esta función devuelve la lista
    return list1


# Función remove()
def remove(list1: list, x):
    """Esta función elimina la primera vez que sale un elemento en una lista.
    Tanto el elemento como la lista se darán como parámetros.
    @param list1: list
    @param x: Any
    @return: list"""

    # Creamos una variable que nos diga si se ha encontrado el elemento buscado
    # y una lista que guarde los elementos finales
    encontrado = False
    list_remove = []

    # Recorremos la lista dada como parámetro
    for elemento in list1:

        # Si el elemento es el buscado y es la primera vez que se encuentra,
        # lo salta
        if elemento == x and not encontrado:
            encontrado = True
            continue

        list_remove += [elemento]

    # Devolvemos la lista final
    return list_remove


# Función removeAll()
def remove_all(list1: list, x):
    """Esta función elimina todas las veces que sale un elemento en una lista.
    Tanto el elemento como la lista se darán como parámetros.
    @param list1: list
    @param x: Any
    @return: list"""

    # Creamos una lista que guarde los elementos finales
    list_remove_all = []

    # Recorremos la lista dada como parámetro
    for elemento in list1:

        # Si el elemento es el buscado, lo salta
        if elemento == x:
            continue

        list_remove_all += [elemento]

    # Devolvemos la lista final
    return list_remove_all


# Función pop()
def pop(list1: list):
    """Esta función elimina el último elemento de una lista y lo devuelve junto
    a la nueva lista. Tanto el elemento como la lista se darán como parámetros.
    @param list1: list
    @return: tuple"""

    # Guardamos el último elemento
    elemento = list1[-1]

    # Eliminamos el último elemento
    list1 = list1[:-1]

    # Esta función devuelve una tupla con la lista final y el elemento
    return list1, elemento


# Función clear()
def clear(list1: list):
    """Esta función elimina todos los elementos de una lista dada.
    @param list1: list
    @return: list"""

    # Le damos el valor de lista vacía
    list1 = []

    # Devolvemos la lista vacía
    return list1


# Mostramos el resultado
lista = [1, 'hola', 5.2, False, 1, 3, 1, 'adiós']
print(lista)

# Ejemplo de count
print('Ejemplo de count:', count(lista, 1))

# Ejemplo de index
print('Ejemplo de index:', index(lista, 'hola'))

# Ejemplo de append
append(lista, True)
print('Ejemplo de append:', lista)

# Ejemplo de find
print('Ejemplo de find:', find(lista, 'hola'))

# Ejemplo de insert
lista = insert(lista, 'sí', 2)
print('Ejemplo de insert:', lista)

# Ejemplo de remove
lista = remove(lista, 'hola')
print('Ejemplo de remove:', lista)

# Ejemplo de remove_all
lista = remove_all(lista, 1)
print('Ejemplo de remove_all:', lista)

# Ejemplo de pop
lista, last = pop(lista)
print('Ejemplo de pop:', lista, last)

# Ejemplo de clear
lista = clear(lista)
print('Ejemplo de clear:', lista)

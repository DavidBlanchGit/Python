"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de funciones.
A continuación se crearán tres funciones: la primera recibira un
número entero en el rango (1, 10), la segunda creará una lista
aleatoria con ese número de elementos y la tercera calculará el
mínimo de la lista."""


# Primera función
def entrada():
    """Esta función pide un número al usuario hasta que se encuentre en el
    rango (1, 10). Después, lo devuelve.
    @return: int"""

    # Iniciamos el número en 0
    num = 0

    # Creamos un bucle que se pida un número hasta que esté en el rango
    while num not in range(1, 10):
        num = int(input("Introduce un número del rango (1, 10): "))

    # Devolvemos el número
    return num


# Segunda función
def random_list(num: int):
    """Esta función genera una lista de números aleatorios. La longitud
    de la lista será la del parámetro indicado.
    @param num: int
    @return: list"""

    # Iniciamos la lista e importamos la librería random
    lista = []
    import random

    # Añadimos elementos aleatorios a la lista
    while len(lista) < num:
        lista.append(random.randint(1, 10))

    # Devolvemos la lista
    print(lista)
    return lista


# Tercera función
def minimo(list1: list):
    """Esta función determina el valor mínimo de una lista dada.
    @param list1: list
    @return: int"""

    # Iniciamos la variable min con el primer elemento de la lista
    min_num = list1[0]

    # Recorremos los elementos de la lista
    for elemento in list1:

        # Si el elemento es menor que min, pasa a ser el nuevo min
        if elemento < min_num:
            min_num = elemento

    # Devolvemos el min
    return min_num


# Mostramos el resultado
print(minimo(random_list(entrada())))

"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de funciones.
A continuación se creará una función que sumule el comportamiento
de la serie de fibonacci."""


# Creamos la función
def fibonacci(num: int):
    """Esta función simula el comportamiento de la serie de fibonacci.
    @param num: int
    @return: list"""

    # Definimos la variable resultado, que será una lista, y dos variables
    # auxiliares
    resultado = []
    num1, num2 = 0, 0

    # Creamos un bucle que se repite hasta que la lungitud de la lista final
    # sea igual a num +1
    while len(resultado) < num + 1:

        # Si la variable num2 es 0, se añade el 0
        if num2 == 0:
            resultado.append(0)
            num2 += 1

        # Si no lo es, se añade su valor, se le da ese valor a la variable
        # num1, y la variable num2 pasa a ser la suma con el elemento anterior
        else:
            resultado.append(num2)
            num1, num2 = num2, num1 + num2

    # Devolvemos el resultado
    return resultado


# Mostramos el resultado
print(fibonacci(7))

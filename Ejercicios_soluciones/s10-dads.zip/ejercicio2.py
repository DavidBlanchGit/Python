"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de funciones.
A continuación se creará una función que devuelva los elementos
no repetidos de dos listas dadas como argumentos."""


# Creamos la función
def combine(list1: list, list2: list):
    """Esta función devuelve una lista con los elementos no repetidos de cada
    una de ellas.
    @param list1: list
    @param list2: list
    @return: list"""

    # Creamos la lista que guardará dichos valores
    combine_list = []

    # Comprobamos cada una de las dos listas iniciales
    for lista in (list1, list2):

        # Comprobamos cada uno de los elementos de cada lista
        for elemento in lista:

            # Si el elemento no está en la lista final, lo añade
            if elemento not in combine_list:
                combine_list.append(elemento)

    # Devolvemos la lista de elementos no repetidos
    return combine_list


# Mostramos el resultado
lista1 = [1, 2, 3, 4, 5, 6]
lista2 = [4, 5, 6, 7, 8, 9]
print(combine(lista1, lista2))
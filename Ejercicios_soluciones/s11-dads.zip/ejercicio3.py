"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de clases.
A continuación se creará una clase Dado que sumule una partida
de dados."""

# Importamos la librería random
import random


# Creamos la clase
class Dados:
    # La iniciamos con los parámetros nombre y tiradas
    def __init__(self, nombre: str, tiradas: int):
        """Esta función inicializa un objeto de la clase cuando esta es llamada.
        @param nombre: str
        @param tiradas: int"""

        # Creamos los atributos nombre y tiradas
        self.nombre = nombre
        self.tiradas = 0 if tiradas < 0 else tiradas

        # Creamos una lista con resultados aleatorios
        self.resultado = []
        for _ in range(self.tiradas):
            self.resultado.append(random.randint(1, 6))

        # Calculamos el mayor numero de dados iguales
        self.iguales = 0
        # Comprobamos cada uno de los 6 posibles números
        for num in range(1, 7):
            # Contamos los dados que hay iguales
            iguales = self.resultado.count(num)

            # Si es mayor que el resultado anterior, se actualiza
            if iguales > self.iguales:
                self.iguales = iguales

        # Calculamos la suma de los elementos
        self.suma = 0
        for elemento in self.resultado:
            self.suma += elemento


# Creamos una lista con los jugadores
lista_jugadores = []

# Solicitamos el número de jugadores
jugadores = int(input("Introduce el número de jugadores: "))

# Pedimos los datos de cada jugador
for n in range(jugadores):
    nombre_jugador = input("Introduce el nombre del jugador %i: "
                           % (n + 1)).capitalize()
    tiradas_jugador = int(input("Introduce el número de tiradas "
                                "que realizará: "))

    # Creamos un objeto de la clase dados con los datos obtenidos
    lista_jugadores.append(Dados(nombre_jugador, tiradas_jugador))

# Imprimimos los resultados de cada jugador
for jugador in lista_jugadores:
    print(jugador.resultado)

# Creamos una lista con el mayor número de dados iguales de cada jugador
lista_iguales = []
for jugador in lista_jugadores:
    lista_iguales.append(jugador.iguales)

# Calculamos el máximo
mejor = max(lista_iguales)

# Comprobamos si es único
unico = True
if lista_iguales.count(mejor) > 1:
    unico = False

# Si es único, el ganador es él
if unico:
    print("El ganador es: %s"
          % lista_jugadores[lista_iguales.index(mejor)].nombre)
else:
    # Creamos una nueva lista con los empatados
    suma_empatados = []

    # Recorremos de nuevo la lista
    for i in range(jugadores):

        # Si tiene la mejor puntuación, se añade su suma
        if lista_iguales[i] == mejor:
            suma_empatados.append(lista_jugadores[i].suma)

        # Si no tenía mejor puntuación, se añade un 0 simbólico
        else:
            suma_empatados.append(0)

    # Calculamos la mejor puntuación
    mejor_suma = max(suma_empatados)

    # Comprobamos si es único con la mejor suma
    unico = True
    if suma_empatados.count(mejor_suma) > 1:
        unico = False

    # Si es único, el ganador es él
    if unico:
        print("El ganador es: %s"
              % lista_jugadores[suma_empatados.index(mejor_suma)].nombre)

    # Si no, todos los de mejor suma son ganadores
    else:
        # Creamos una lista con los nombres de los ganadores
        ganadores = []

        # Recorremos la lista
        for j in range(jugadores):

            # Si el jugador tiene la mejor suma se añade a jugadores
            if suma_empatados[j] == mejor_suma:
                ganadores.append(
                    lista_jugadores[suma_empatados.index(j)].nombre
                )

        # Mostramos los ganadores
        print("Los ganadores son *%s" % ganadores)

"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de clases.
A continuación se crearán las clases necesarias para el proyecto
final de la asignatura."""

# Importamos algunos métodos de la librería random
from random import random
from random import randint

# Constantes necesarias para ancho y altura
WIDTH = 160
HEIGHT = 192

# Constantes necesarias para la clase Background y la clase BolquesIniciales
NUBE_COUNT = 5
BLOQUE_COUNT = 40


# Clase que define el fondo
class Background:
    # Se inicia sin parámetros
    def __init__(self):

        # Crea una lista de 5 nubes con posición y velocidad y  aleatorias
        self.point_list = []
        for i in range(NUBE_COUNT):
            self.point_list.append(
                (random() * 1.5 * WIDTH,
                 random() / 1.75 * HEIGHT,
                 random() + 0.75)
            )


# Clase que define los bloques iniciales
class BloquesIniciales:
    # Se inicia sin parámetros
    def __init__(self):

        # Crea una lista de 40 bloques con posicines aleatorias
        self.point_list = []
        for i in range(BLOQUE_COUNT):
            self.point_list.append(
                (randint(0, 10) * 16, randint(0, 10) * 16 + 32)
            )


# Clase de los personajes del juego
class Lemming:
    # Necesita los parámetros de posición en los ejes x, y
    def __init__(self, x, y):

        # Comprueba si son correctas, si no las inicia en 0
        self.x = 0 if (x < 0 or x > WIDTH) else x
        self.y = 0 if (y < 0 or y > HEIGHT) else y

        # Valores de altura y anchura
        self.w = 6
        self.h = 16


# Clase de la herramienta escalera
class Escalera:
    # Necesita los parámetros de posición en los ejes x, y
    def __init__(self, x, y):

        # Comprueba si son correctas, si no las inicia en 0
        self.x = 0 if (x < 0 or x > WIDTH) else x
        self.y = 0 if (y < 0 or y > HEIGHT) else y

        # Valores de altura y anchura
        self.w = 16
        self.h = 16


# Clase de la herramienta paraguas
class Paraguas:
    # Necesita los parámetros de posición en los ejes x, y
    def __init__(self, x, y):

        # Comprueba si son correctas, si no las inicia en 0
        self.x = 0 if (x < 0 or x > WIDTH) else x
        self.y = 0 if (y < 0 or y > HEIGHT) else y

        # Valores de altura y anchura
        self.w = 16
        self.h = 16


# Clase de la herramienta bloque
class Bloque:
    # Necesita los parámetros de posición en los ejes x, y
    def __init__(self, x, y):

        # Comprueba si son correctas, si no las inicia en 0
        self.x = 0 if (x < 0 or x > WIDTH) else x
        self.y = 0 if (y < 0 or y > HEIGHT) else y

        # Valores de altura y anchura
        self.w = 16
        self.h = 16


# Clase del selector con el que se colocan objetos
class Selector:
    # Se inicia sin parámetros
    def __init__(self):

        # Se inicia en la posición 0, 0
        self.x = 0
        self.y = 0

        # Valores de altura, anchura y color
        self.w = int(WIDTH/10)
        self.h = int(WIDTH/10)
        self.col = 7


# Clase principal, donde se juntan todas las clases
class App:

    # Se inicia sin parámetros
    def __init__(self):

        # Inicia como atributos las clases siguientes
        self.bloques = BloquesIniciales()
        self.selector = Selector()
        self.background = Background()

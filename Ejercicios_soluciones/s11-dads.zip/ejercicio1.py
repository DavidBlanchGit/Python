"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de clases.
A continuación se creará una clase Estudiante con varios
atributos y se comprobará si son correctos."""


# Creamos la clase
class Estudiante:
    def __init__(self, nombre: str, apellidos: str, programacion: int, algebra: int,
                 calculo: int, fisica: int, tecnicas: int, humanidades: int):
        """Esta función inicia un objeto con los parametros introducidos, añadiendolos
        a los atributos de la clase.
        @param nombre: str
        @param apellidos: str
        @param programacion: int
        @param algebra: int
        @param calculo: int
        @param fisica: int
        @param tecnicas: int
        @param humanidades: int"""

        # Atributos nombre y apellidos
        self.nombre = nombre
        self.apellidos = apellidos

        # Los atributos de notas los iniciamos en 0 si es una nota no válida
        self.programacion = 0 if programacion not in range(11) else programacion
        self.algebra = 0 if algebra not in range(11) else algebra
        self.calculo = 0 if calculo not in range(11) else calculo
        self.fisica = 0 if fisica not in range(11) else fisica
        self.tecnicas = 0 if tecnicas not in range(11) else tecnicas
        self.humanidades = 0 if humanidades not in range(11) else humanidades

    def __str__(self):
        """Esta función devuelve una cadena de texto con los parámetros introducidos
        cuando se intenta imprimir un objeto:
        @return: str"""

        resultado = (self.nombre + " " + self.apellidos + ": " + str(self.programacion) +
                     ", " + str(self.algebra) + ", " + str(self.calculo) + ", " +
                     str(self.fisica) + ", " + str(self.tecnicas) + ", " +
                     str(self.humanidades))

        return resultado


# Pedimos los datos
nombre_alumno = input("Introduce el nombre del alumno: ").capitalize()
apellido_alumno = input("Introduce el apellido del alumno: ").capitalize()
nota_programacion = int(input("Introduce la nota de programación: "))
nota_algebra = int(input("Introduce la nota de álgebra: "))
nota_calculo = int(input("Introduce la nota de cálculo: "))
nota_fisica = int(input("Introduce la nota de física: "))
nota_tecnicas = int(input("Introduce la nota de técnicas: "))
nota_humanidades = int(input("Introduce la nota de humanidades: "))


# Creamos una objeto de la clase Estudiante con esos datos
alumno = Estudiante(nombre_alumno, apellido_alumno, nota_programacion, nota_algebra,
                    nota_calculo, nota_fisica, nota_tecnicas, nota_humanidades)


# Mostramos el resultado
print(alumno)

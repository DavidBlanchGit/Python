"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de clases.
A continuación se creará una clase TrianguloRectángulo y
se realizarán operaciones con ella."""


# Creamos la clase
class TrianguloRectangulo:
    # Se inicia con dos parámetros, base y altura
    def __init__(self, base: float,  altura: float):
        """Esta función inicializa un objeto de la clase cuando es llamada.
        @param base: float
        @param altura: float"""

        # Si los valores no son correctos, los atributos se inician en 0
        self.base = 0 if base <= 0 else base
        self.altura = 0 if altura <= 0 else altura

        # Pulse 0 para calcular el área del triángulo o 1 para el perímetro
        accion = int(input("Pulse 0 para calcular el área del triángulo "
                           "o 1 para el perímetro: "))

        if accion == 0:
            area = self.base * self.altura / 2
            print("El área es: %.2f" % area)

        if accion == 1:
            hipotenusa = (self.base ** 2 + self.altura ** 2) ** 0.5
            perimetro = self.base + self.altura + hipotenusa
            print("El perimetro es: %.2f" % perimetro)


# Pedimos los datos de la base y altura
base1 = int(input("Introduce el valor de la base: "))
altura1 = int(input("Introduce el valor de la altura: "))

# Mostramos el resultado
triangulo = TrianguloRectangulo(base1, altura1)

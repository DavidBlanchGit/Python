"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de clases.
A continuación se creará una clase Intervalo temporal y se
realizarán operaciones con ella."""


# Creamos una función para pasar de str a horas
def time_to_float(time: str):
    """Esta función convierte en un número entero una hora introducida en str
    de la forma hh:mm.
    @param time: str
    @return: float"""

    # Comprobamos si el símbolo ':' se encuentra en la cadena de texto
    if ":" in time:

        # El valor de las horas es el de la izquierda y
        # el de los minutos el de la derecha
        hours = int(time[:time.index(":")])
        mins = int(time[time.index(":") + 1:])

        # Si el valor de minutos es incorrecto, se pone en 0
        if mins > 59:
            mins = 0

    # Si no está el símbolo, solo son horas
    else:
        hours = int(time)
        mins = 0

    # Pasamos los minutos a horas y se lo sumamos a las horas
    total = hours + round(mins / 60, 3)

    # Devolvemos el valor
    return total


def calculo_intervalo(hora: float):
    """Esta función calcula a qué intervalo pertenece una hora.
    @param hora: float
    @return: str"""

    # Creamos la variable que devolveremos después
    intervalo_horario = ''

    # Calculamos el intervalo
    if 0 <= hora < 6:
        intervalo_horario = 'madrugada'

    if 6 <= hora < 12:
        intervalo_horario = 'mañana'

    if 12 <= hora < 18:
        intervalo_horario = 'tarde'

    if 18 <= hora < 24:
        intervalo_horario = 'noche'

    return intervalo_horario


# Creamos una lista con los posibles intervalos
intervalos = ['madrugada', 'mañana', 'tarde', 'noche']


# Creamos la clase
class IntervaloTemporal:
    # La iniciamos con dos horas como parámetros
    def __init__(self, inicio: str, final: str):
        """Esta función inicializa un objeto de la clase cuando esta es llamada.
        @param inicio: str
        @param final: str"""

        # Atributos
        self.inicio_str = inicio
        self.final_str = final

        # Iniciamos los atributos pasandolo a float
        self.inicio = time_to_float(inicio)
        self.final = time_to_float(final)

        # Comprobamos si son correctos
        if not (0 <= self.inicio < 24):
            self.inicio = self.final

        if not (0 <= self.final < 24):
            self.final = 0
            self.inicio = 0

        # Si el inicio es mayor que el final, damos la vuelta
        if self.inicio > self.final:
            self.inicio, self.final = self.final, self.inicio

        # Creamos los atributos de intervalo
        self.intervalo1 = calculo_intervalo(self.inicio)
        self.intervalo2 = calculo_intervalo(self.final)

        # Atributo con el intervalo
        self.intervalos = intervalos[
                          intervalos.index(self.intervalo1):intervalos.index(self.intervalo2) + 1
                          ]

    def __str__(self):
        """Esta función modifica el texto al imprimir un objeto de esta clase.
        @return: str"""

        intervalos_str = ''
        for n in self.intervalos:
            intervalos_str += str(n) + ' '

        mensaje = "Initervalo temporal: [%s-%s] \n Pertenece a: " % \
                  (self.inicio_str, self.final_str) + intervalos_str

        return mensaje


# Mostramos el resultado
numero_intervalos = int(input("Introduce el número de intervalos que desea"
                              " calcular: "))

# Creamos una lista con los intervalos del usuario
intervalos_usuario = []

# Pedimos los datos de cada intervalo
for _ in range(numero_intervalos):
    hora_inicio = input("Introduce el inicio del intervalo %i: " % (_ + 1))
    hora_final = input("Introduce el final del intervalo %i: " % (_ + 1))

    intervalos_usuario.append(IntervaloTemporal(hora_inicio, hora_final))

# Imprimimos el resultado
for elemento in intervalos_usuario:
    print(elemento)

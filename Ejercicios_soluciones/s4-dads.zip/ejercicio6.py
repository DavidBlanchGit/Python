"""Autor : Daniel Alonso
Fecha : 11/10/2020
Python version : 3.8
Descripción : Este es un programa de cálculo del
precio de una entrada de cine a partir de la edad
del comprador. A continuación se pedirá una edad y
se calculará el precio de la entrada."""

# Precio sin aplicar descuento
precio = 9

# Edad del usuario
edad = int(input("¿Qué edad tienes? "))

# Cálculo del precio
if edad < 5:
    precio *= 0.4
elif edad < 26:
    precio *= 0.8
elif edad >= 65:
    precio *= 0.6
precio = round(precio, 2)
print("El precio de la entrada es de", precio,"euros.")
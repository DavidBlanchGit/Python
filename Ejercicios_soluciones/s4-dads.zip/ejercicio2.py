"""Autor : Daniel Alonso
Fecha : 11/10/2020
Python version : 3.8
Descripción : Este es un programa de operaciones con
variable. A continuación se declararán cuatro variables
y se realizarán operaciones."""

# Estas son las cuatro variables
a, b, c, d = 5, 3, 20, 20

# Esto le resta al valor c el resultado de las operaciones siguientes
c -= (a + 1) / b - 3 + a % b

# Esto le resta al valor c el resultado de las operaciones siguientes
d -= (a + 1) / (b + 3 - 4 * a) % b

# Esto imprime los valores
print("c:", c)
print("d:", d)
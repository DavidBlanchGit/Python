"""Autor : Daniel Alonso
Fecha : 11/10/2020
Python version : 3.8
Descripción : Este es un programa de división de
enteros. A continuación se declararán dos variables
enteras y se imprimirá su división."""

# Estas son las variables tomadas por teclado
num1 = int(input("Introduce un número entero: "))
num2 = int(input("Introduce otro número entero: "))

# Esto imprime la división
if num2 != 0:
    div = num1 / num2
    print("La división de", num1, "entre", num2, "es", div)
else:
    print("No se puede dividir entre cero usando enteros.")
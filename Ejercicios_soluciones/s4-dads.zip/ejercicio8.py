"""Autor : Daniel Alonso
Fecha : 11/10/2020
Python version : 3.8
Descripción : Este es un programa de declaración del
tipo de una variable. A continuación se declarará una
variable a través de un input y se comprobará si es
número o no."""

# Esta es la variable
caracter = input("Escribe un carácter: ")

# Esto comprueba si en esa cadena de texto hay algún número
for numero in range(0, 10):
    if str(numero) in caracter:
        print("Es un número.")
        break
    elif numero == 9:
        print("No es un número.")
"""Autor : Daniel Alonso
Fecha : 11/10/2020
Python version : 3.8
Descripción : Este es un programa de cálculo de
coordenadas. A continuación se pedirán dos números
y se calculará el cuadrante al que pertenecen."""

# Estas son las variables de las coordenadas
coor_x = int(input("Introduce la coordenada X: "))
coor_y = int(input("Introduce la coordenada Y: "))

# Esto calcula el cuadrante al que pertenece
if coor_x == 0 or coor_y == 0:
    print("No se puede calcular el cuadrante por tener un valor igual a 0")
elif coor_x > 0 and coor_y > 0:
    print("El punto se encuentra en el primer cuadrante.")
elif coor_x < 0 and coor_y > 0:
    print("El punto se encuentra en el segundo cuadrante.")
elif coor_x < 0 and coor_y < 0:
    print("El punto se encuentra en el tercer cuadrante.")
else:
    print("El punto se encuentra en el cuarto cuadrante.")
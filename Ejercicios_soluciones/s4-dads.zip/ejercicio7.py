"""Autor : Daniel Alonso
Fecha : 11/10/2020
Python version : 3.8
Descripción : Este es un programa de cálculo del
equivalente a horas/minutos/segundos de una cantidad
de segundos introducidos por teclado. A continuación
se pedirá una cantidad y se calculará su equivalente."""

# Cantidad de segundos
seg = int(input("¿Cuántos segundos quiere calcular? "))

# Cálculo de horas
horas = str(seg // 3600)
seg %= 3600

# Cálculo de minutos
min = str(seg // 60)
seg %= 60
seg = str(seg)

# Esto sirve para añadir un cero si el valor de
# horas, min o seg tienen menos de dos cifras
if len(horas) < 2:
    horas = "0" + horas
if len(min) < 2:
    min = "0" + min
if len(seg) < 2:
    seg = "0" + seg

# Esto imprime el valor final
print(horas + ":" + min + ":" + seg)
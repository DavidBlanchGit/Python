"""Autor : Daniel Alonso
Fecha : 11/10/2020
Python version : 3.8
Descripción : Este es un programa de cálculo de
año bisiesto. A continuación se pedirá un año por
teclado y se calculará si es bisiesto."""

# Variables
año = int(input("¿Qué año quiere calcular? "))
bisiesto = False

# Esto calcula si es bisiesto o no
if año % 4 == 0 and año % 100 != 0:
    bisiesto = True
elif año % 100 == 0 and año % 400 == 0:
    bisiesto = True

# Esto imprime el resultado
if año <= 2020 and bisiesto:
    print("El año", año, "fue bisiesto.")
elif año >= 2020 and bisiesto:
    print("El año", año, "será bisiesto.")
elif año <= 2020 and not bisiesto:
    print("El año", año, "no fue bisiesto.")
else:
    print("El año", año, "no será bisiesto.")
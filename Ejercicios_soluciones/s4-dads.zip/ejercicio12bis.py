"""Autor : Daniel Alonso
Fecha : 11/10/2020
Python version : 3.8
Descripción : Este es un programa de desglose en
monedas y billetes de una cantidad introducida. Es
una variante del ejercicio anterior."""

# Esto es un diccionario con los valores de monedas y billetes
monedas = {50000: "Billetes de 500€", 20000: "Billetes de 200€",
          10000: "Billetes de 100€", 5000: "Billetes de 50€",
          2000: "Billetes de 20€", 1000: "Billetes de 10€",
          500: "Billetes de 5€", 200: "Monedas de 2€", 100: "Monedas de 1€",
          50: "Monedas de 50cent", 20: "Moneda de 20cent", 10: "Monedas de 10cent",
          5: "Monedas de 5cent", 2: "Monedas de 2cent", 1: "Monedas de 1cent"}

# Esta es una lista con los posibles valores
valores = [50000, 20000, 10000, 5000, 2000, 1000, 500, 200, 100, 50,
           20, 10, 5, 2, 1]

# Cálculo del desglose
dinero = float(input("¿Qué cantidad desea calcular? ")) * 100
for valor in valores:
    cantidad = int(dinero // valor)
    dinero -= cantidad * valor
    if cantidad != 0:
        print(monedas.get(valor) + ":", cantidad)
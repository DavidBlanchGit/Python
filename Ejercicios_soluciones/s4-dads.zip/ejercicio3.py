"""Autor : Daniel Alonso
Fecha : 11/10/2020
Python version : 3.8
Descripción : Este es un programa de impresión de
variables. A continuación se declararán varias variables
y se imprimirán."""

a = 3
b = 8
c = 3.0

# r = False porque a == 0 es False
r = a == 0

# s = True porque a != 0 es True
s = a != 0

# t = True porque a <= b es True
t = a <= b

# u = True porque b >= a es True
u = b >= a

# v = True porque b > a es True
v = b > a

# w = False porque b < a es False
w = b < a

# x = True porque c == 3.0 es True
x = c == 3.0

# Esto imprime los valores
print("r:", r)
print("s:", s)
print("t:", t)
print("u:", u)
print("v:", v)
print("w:", w)
print("x:", x)
"""Autor : Daniel Alonso
Fecha : 11/10/2020
Python version : 3.8
Descripción : Este es un programa de desglose en
monedas y billetes de una cantidad introducida. Se
pedirá una cantidad y posteriormente se calculará
el mejor desglose."""

# Esta es la variable en céntimos
cantidad = int(float(input("Introduce una cantidad de dinero: ")) * 100)

# Cálculo del desglose
if cantidad // 50000 != 0:
    b500 = cantidad // 50000
    cantidad %= 50000
    print("500€:", b500)
if cantidad // 20000 != 0:
    b200 = cantidad // 20000
    cantidad %= 20000
    print("200€:", b200)
if cantidad // 10000 != 0:
    b100 = cantidad // 10000
    cantidad %= 10000
    print("100€:", b100)
if cantidad // 5000 != 0:
    b50 = cantidad // 5000
    cantidad %= 5000
    print("50€:", b50)
if cantidad // 2000 != 0:
    b20 = cantidad // 2000
    cantidad %= 2000
    print("20€:", b20)
if cantidad // 1000 != 0:
    b10 = cantidad // 1000
    cantidad %= 1000
    print("10€:", b10)
if cantidad // 500 != 0:
    b5 = cantidad // 500
    cantidad %= 500
    print("5€:", b5)
if cantidad // 200 != 0:
    m200 = cantidad // 200
    cantidad %= 200
    print("2€:", m200)
if cantidad // 100 != 0:
    m100 = cantidad // 100
    cantidad %= 100
    print("1€:", m100)
if cantidad // 50 != 0:
    m50 = cantidad // 50
    cantidad %= 50
    print("0,50€:", m50)
if cantidad // 20 != 0:
    m20 = cantidad // 20
    cantidad %= 20
    print("0,20€:", m20)
if cantidad // 10 != 0:
    m10 = cantidad // 10
    cantidad %= 10
    print("0,10€:", m10)
if cantidad // 5 != 0:
    m5 = cantidad // 5
    cantidad %= 5
    print("0,05€:", m5)
if cantidad // 2 != 0:
    m2 = cantidad // 2
    cantidad %= 2
    print("0,02€:", m2)
if cantidad // 1 != 0:
    m1 = cantidad // 1
    cantidad %= 1
    print("0,01€:", m1)
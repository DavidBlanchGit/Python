"""Autor : Daniel Alonso
Fecha : 11/10/2020
Python version : 3.8
Descripción : Este es un programa de simulación de
una calculadora. A continuación se pedirán dos números
y una operación y se mostrará el resultado."""

# Variables
num1 = int(input("Introduce un número: "))
num2 = int(input("Introduce otro número: "))
oper = input("Operación que desea realizar: ")

# Cálculo del resultado
# Para la resta
if oper == "-" or oper == "resta" or oper == "restar":
    res = num1 - num2
# Para la suma
elif oper == "+" or oper == "suma" or oper == "sumar":
    res = num1 + num2
# Para la multiplicación
elif oper == "*" or oper == "multiplicación" or oper == "multiplicar":
    res = num1 * num2
# Para la división
elif oper == "/" or oper == "división" or oper == "dividir":
    if num2 != 0:
        res = num1 / num2
    else:
        res = "No se puede calcular."
        print("El divisor no puede ser 0.")
# Para la división entera
elif oper == "//" or oper == "división entera" or oper == "dividir parte entera":
    if num2 != 0:
        res = num1 // num2
    else:
        res = "No se puede calcular."
        print("El divisor no puede ser 0.")
# Para la potencia
elif oper == "**" or oper == "potencia" or oper == "elevar":
    res = num1 ** num2
# Para un operador no válido
else:
    res = "No se puede calcular."
    print("Operador no válido.")
print("El resultado es:", res)
"""Autor : Daniel Alonso
Fecha : 11/10/2020
Python version : 3.8
Descripción : Este es un programa de cálculo de
sueldo de un operario. A continuación se pedirán
el sueldo y los años trabajados del operario y se
calculará el nuevo sueldo."""

# Estos son los datos del operario
sueldo = int(input("¿Cuál es el sueldo del operario? "))
años = int(input("¿Cuántos años lleva trabajando el operario? "))

# Esto calcula el nuevo sueldo
if sueldo < 1000 and años >= 10:
    sueldo *= 1.2
elif sueldo < 1000 and años < 10:
    sueldo *= 1.05

# Esto imprime el sueldo
print("El nuevo sueldo del operario es:", sueldo)
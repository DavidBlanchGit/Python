"""Autor : Daniel Alonso
Fecha : 11/10/2020
Python version : 3.8
Descripción : Este es un programa de comparación de
edades. A continuación se pedirán dos nombres y dos
edades y se compararán."""

# Esto recoge los datos del usuario 1
name1 = input("Introduce un nombre: ")
age1 = int(input("¿Qué edad tiene " + name1 + "? "))

# Esto recoge los datos del usuario 2
name2 = input("Introduce un nombre: ")
age2 = int(input("¿Qué edad tiene " + name2 + "? "))

# Esto calcula quien es el mayor
if age1 == age2:
    print(name1, "y", name2, "tienen la misma edad.")
elif age1 < age2:
    print(name1 + " es menor que " + name2 + ".")
else:
    print(name1 + " es mayor que " + name2 + ".")
"""Autor : Daniel Alonso
Fecha : 11/10/2020
Python version : 3.8
Descripción : Este es un programa de operaciones con
una variable. A continuación se declarará una
variable y se realizarán operaciones."""

a = 4

# Esto suma 2 a la variable "a"
a += 2
print(a)

# Esto resta 3 a la variable "a"
a -= 3
print(a)

# Esto multiplica por 3 a la variable "a"
a *= 3
print(a)

# Esto divide entre 2 la variable "a"
a /= 2
print(a)

# Esto da el resto de dividir entre 4 a la variable "a"
a %= 4
print(a)

# Esto da la parte entera de dividir entre 2 a la variable "a"
a //= 2
print(a)
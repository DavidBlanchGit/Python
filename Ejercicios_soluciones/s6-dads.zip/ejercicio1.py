"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de inicialización de
listas. A continuación se generará una lista y se
realizarán varias operaciones."""

# Esta es la lista
lista = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print(lista)

# Primera asignación de elementos
lista[5] = lista[2]
print(lista[5], lista[2])
print(lista)

# Segunda asignación, cambio del valor de lista[2]
lista[2] = 0
print(lista[5], lista[2])
print(lista)

"""Como podemos ver, en la primera asignación, al cambiar el valor del sexto 
elemento al del tercero, ambos tienen el mismo valor. Sin embargo, cuando 
cambiamos el valor de este último, el otro no cambia. Esto se debe a que 
en la primera asignación, lista[5] toma el valor en ese momento de lista[2],
y no tiene en cuenta si en el futuro cambia. Para que fuese siempre igual,
cada vez que lista[2] cambia de valor habría que poner: lista[5] = lista[2]"""
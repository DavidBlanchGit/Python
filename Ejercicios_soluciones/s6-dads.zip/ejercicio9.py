"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de creación de
tuplas. A continuación se generará una tupla con
números aleatorios entre 1 y 10 que corresponden
a las notas de los jueces. Posteriormente se
mostrarán en pantalla y se calculará la nota máxima
y la mínima."""

# Creación de tupla
import random
notas = []
for n in range(5):
    num = random.randrange(1, 11)
    notas.append(num)
notas = tuple(notas)
print(notas)

# Salida de notas
for n in range(5):
    nota = notas[n]
    if nota == 1:
        print("El juez %i da al gimnasta %i punto." % (n + 1, nota))
    else:
        print("El juez %i da al gimnasta %i puntos." % (n + 1, nota))

# Máximo y mínimo
max, min = 0, 11
for nota in notas:
    if nota < min:
        min = nota
    if nota > max:
        max = nota

# Resultado
print("La menor puntuación obtenida es %i y la mayor puntuación es %i." % (min, max))
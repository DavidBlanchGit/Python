"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de inicialización de
listas. A continuación se generará una lista y se
harán copias de distintas formas."""

# Creación de la lista1 con elementos aleatorios
import random
lista1 = []
for num in range(25):
    elemento = random.randrange(100)
    lista1.append(elemento)
print(lista1)

# Copia de la lista mediante '='
lista2 = lista1

# ¿Qué pasa si cambio uno de los elementos?
lista1[0] = 0
print(lista1, lista2)

"""De esta forma, al copiar la lista1 en lista2 con '=', estamos recurriendo
al mismo espacio de memoria, por lo que si una cambia la otra tambien."""

# Creación de la lista3 con elementos aleatorios
lista3 = []
for num in range(25):
    elemento = random.randrange(100)
    lista3.append(elemento)
print(lista3)

# Copia de la lista mediante un bucle
lista4 = []
for elemento in lista3:
    lista4.append(elemento)

# ¿Qué pasa si cambio uno de los elementos?
lista3[0] = 0
print(lista3, lista4)

"""Con esta otra forma, al copiar la lista1 en lista2 con un bucle, estamos 
guardando los valores de cada elemento de lista3 en unn nuevo espacio de memoria
al que recurrirá lista4, por lo que al cambiar un elemento de lista3, lista4 
seguirá igual."""
"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de creación de
tuplas. A continuación se generará una tupla con
los meses del año y se pedirá un número para encontrar
el mes correspondiente."""

# Generar la tupla
meses = ("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre"
         , "octubre", "noviembre", "diciembre")

# Número del mes
num_mes = int(input("¿Qué número de mes quiere calcular? "))
while num_mes not in range(1, 13):
    print("Número no válido. Introduce un número entero entre 1 y 12.")
    num_mes = int(input("¿Qué número de mes quiere calcular? "))

# Cálculo del mes
print("El mes correspondiente al número %i es: %s" % (num_mes, meses[num_mes - 1]))
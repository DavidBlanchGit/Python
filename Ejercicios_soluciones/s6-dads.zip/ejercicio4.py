"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de búsqueda de
elementos en una lista. A continuación se generará
una lista con valores aleatorios entre 1 y 9.
Posteriormente se le pedirá al usuario que elija
un número y se buscará en la lista."""

# Declaración lista
import random
lista = []
for n in range(20):
    elemento = random.randrange(1, 10)
    lista.append(elemento)
print(lista)

# Pedimos al usuario un número
num = int(input("Introduzca un número entero entre 1 y 9: "))
while num not in range(1, 10):
    num = int(input("Introduzca un número entero entre 1 y 9: "))

# Comprobar si el número está en la lista
if num in lista:
    print("El número seleccionado se encuentra en la lista.")
    print("Veces que aparece el número: %i" % lista.count(num))
    print("Posiciones en las que aparece:", end = " ")
    cont = 0
    pos = ""
    for elemento in lista:
        cont += 1
        if elemento == num:
            pos += str(cont) + ", "
    print(pos[: -2])
else:
    print("El número seleccionado no se encuentra en la lista.")

"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de adivinación de
un número. A continuación se pedirá al usuario que
piense un número y tratará de acertarlo."""

# Presentación del programa
print("PROGRAMA DE ADIVINACIÓN DE UN NÚMERO")
print("Piense en un número entre el 1 y el 100")

# Declaración de variables
import random
intentos = 0
encontrado = False
numeros = []
for n in range(1, 101):
    numeros.append(n)

# Generación de números aleatorios sin repetir
while not encontrado and len(numeros) > 0:
    num_aleatorio = random.randrange(len(numeros))
    num = numeros.pop(num_aleatorio)
    resp = input("¿El número que estabas pensando es el %i? (S/N) " % num).upper()
    intentos += 1
    if resp == "S":
        encontrado = True

# Resultado
if not encontrado and len(numeros) == 0:
    print("¡Todos los números probados! Tu número no estaba entre 1 y 100.")
else:
    print("¡Número encontrado! Número de intrentos: %i" % intentos)
"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de suma de los elementos
de una lista. A continuación se generará una lista de la
longitud que el usuario decida y se inicializará con valores
aleatorios entre 1 y 49. Posteriormente se sumarán."""

# Preguntamos por el tamaño
tamaño = int(input("¿De que tamaño quiere que sea su lista? "))
while tamaño <= 0:
    print("Tamaño no válido. Introduzca un número mayor que 0")
    tamaño = int(input("¿De que tamaño quiere que sea su lista? "))

# Creación de lista
import random
lista = []
for num in range(tamaño):
    elemento = random.uniform(1, 49)
    lista.append(elemento)

# Suma de la parte entera de elementos
total = 0
for elemento in lista:
    elemento2 = int(elemento)
    total += elemento2

# Resultados
print(lista, "\nEl valor total de la parte entera de los elementos de la lista es: %i" % total)
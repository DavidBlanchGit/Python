"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de cálculo del
tiempo que tarda en realizarse el programa. A continuación
se creará una lista de distintas formas y se calcularán
los tiempos de ejecución."""

# Importamos las librerías tiempo y random
import time
import random

# Mediante .append()
inicio1 = time.time()

lista1 = []
for n in range(100000):
    num = random.randrange(1, 101)
    lista1.append(num)

final1 = time.time()

# Cálculo del tiempo
tiempo1 = final1 - inicio1
print("Con el método append() el programa tarda %f segundos." % tiempo1)

# Mediante el operador +=
inicio2 = time.time()

lista2 = []
for n in range(100000):
    num = random.randrange(1, 101)
    lista2 += [num]

final2 = time.time()

# Cálculo del tiempo
tiempo2 = final2 - inicio2
print("Con el método += el programa tarda %f segundos." % tiempo2)

# Mediante el operador +
inicio3 = time.time()

lista3 = []
for n in range(100000):
    num = random.randrange(1, 101)
    lista3 = lista3 + [num]

final3 = time.time()

# Cálculo del tiempo
tiempo3 = final3 - inicio3
print("Con el método + el programa tarda %f segundos." % tiempo3)
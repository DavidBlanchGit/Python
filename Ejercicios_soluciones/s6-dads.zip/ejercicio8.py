"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de creación de
tuplas. A continuación se generará una tupla con
los carácteres no repetidos de una frase introducida
por el usuario."""

# Pedir frase al usuario
frase = input("Introduce una frase: ").upper()

# Creación de lista
lista = []
for caracter in frase:
    if caracter not in lista:
        lista.append(caracter)

# Creación  e impresión de tupla
tupla = tuple(lista)
print(tupla)
"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de funciones.
A continuación se creará una función que calcule los días de
un mes de un determinado año."""


# Creamos la función
def calculo_dias(mes: int, año: int):
    """Esta función calcula los días que tiene un mes de un determinado año,
    teniendo en cuenta los años bisiestos.
    @param mes: int
    @param año: int
    @return: int"""

    # Diccionario con los días de cada mes
    calendario = {1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30,
              7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31}

    # Si el año es bisiesto sumamos un día a febrero
    if año % 4 == 0:
        if año % 100 == 0:
            if año % 400 == 0:
                calendario[2] += 1
        else:
            calendario[2] += 1

    # Calculamos los días
    dias = calendario[mes]

    return dias


# Mostramos el resultado
mes = int(input("Introduce el número del mes: "))
año = int(input("Introduce el año: "))
print("Tiene %i días." % calculo_dias(mes, año))


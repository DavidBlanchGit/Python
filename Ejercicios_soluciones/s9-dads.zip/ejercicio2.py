"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de funciones.
A continuación se crearán dos funciones. La primera generará una
lista de 10 números pares, la segunda calculará las propiedades
de una lista."""


# Primera función
def crear_lista_numeros():
    """Esta función crea una lista con solo números pares. Los elementos serán
    aleatorios y la longitud de la lista de 10 elementos.
    @return: lista"""

    # Importamos la librería random
    import random

    # Creamos una lista con los números pares hasta el 100
    pares = []
    for n in range(100):
        if n % 2 == 0:
            pares.append(n)

    # Creamos la lista de elementos aleatorios
    lista = []
    for elemento in range(10):
        lista.append(random.choice(pares))

    return lista


# Mostramos el resultado
lista = crear_lista_numeros()
print(lista)


# Segunda función
def calcular_propiedades(lista: list):
    """Esta función devuelve el máximo, el mínimo y la media de los valores de
    una lista.
    @param lista: lista de números
    @return: diccionario con el máximo, el mínimo y la media"""

    # Calculamos el máximo, el mínimo y la media
    maximo, minimo, suma = lista[0], lista[0], 0
    for num in lista:
        suma += num
        if num > maximo:
            maximo = num
        if num < minimo:
            minimo = num
    media = suma / len(lista)

    return {'máximo': maximo, 'mínimo': minimo, 'media': media}


# Mostramos el resultado
print(calcular_propiedades(lista))
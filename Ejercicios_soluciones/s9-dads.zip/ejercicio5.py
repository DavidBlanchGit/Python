"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de funciones.
A continuación se creará una función que ponga las mayúsculas
necesarias en una cadena de texto dada."""


# Creamos la función
def escribir_mayusculas(cadena: str):
    """Esta función escribe de forma correcta las mayúsculas de una cadena de
    texto dada.
    @param cadena: string
    @return: string"""

    # Esta variable determinará si la siguiente letra va en mayúscula o no
    mayuscula = True

    # Resto de variables
    cadena_final = ''
    simbolos = ['.', '?', '!']

    # Creamos un bucle que recorre los elementos de la cadena
    for caracter in cadena:

        # Si es uno de los simbolos, la siguiente letra irá en mayúscula
        if caracter in simbolos:
            mayuscula = True

        # Si mayúscula es True y el carácter es una letra, se pone en mayus
        if mayuscula and caracter.isalpha():
            cadena_final += caracter.upper()
            mayuscula = False
            continue

        cadena_final += caracter

    return cadena_final


# Mostramos el resultado
cadena = input("Escribe algo: ")
print(escribir_mayusculas(cadena))
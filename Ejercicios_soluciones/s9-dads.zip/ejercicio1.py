"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de funciones.
A continuación se creará una función que genere una contraseña
aleatoria con letras, números y símbolos."""


# Creamos listas con los posibles caracteres
num = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

simbol = ['!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.',
          '/', ':', ';', '<', '>', '=', '?', '@', '[', ']', '_', '^', '{', '}',
          '|', '\\', '`', '~']

letras = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
          'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

letras_mayus = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
                'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

caracteres = {'letras': letras, 'mayusculas': letras_mayus, 'numeros': num,
              'simbolos': simbol}


# Creamos la función
def nueva_contraseña():
    """Esta función generará una contraseña de caracteres aleatorios y longitud
    aleatoria comprendida entre 8 y 12. Además, incluirá al menos un carácter de
    cada tipo.
    @return: string"""

    # Importamos la librería random
    import random

    # Variables que nos dicen el número de elementos de cada tipo
    num_letras, num_num, num_mayus, num_simb = 0, 0, 0, 0

    # Creamos un bucle para que la contraseña tenga al menos un carácter de cada
    while num_letras == 0 or num_mayus == 0 or num_num == 0 or num_simb == 0:

        # Iniciamos las variables contraseña y longitud
        contraseña = ''
        longitud = random.randint(8, 12)
        num_letras, num_num, num_mayus, num_simb = 0, 0, 0, 0

        # Creamos un bucle que corresponde con la longitud
        for n in range(longitud):
            tipo_caracter = random.choice(list(caracteres.keys()))

            # Los concicionales cuentan el número de cada tipo de caracter
            if tipo_caracter == 'letras':
                num_letras += 1
            elif tipo_caracter == 'mayusculas':
                num_mayus += 1
            elif tipo_caracter == 'numeros':
                num_num += 1
            elif tipo_caracter == 'simbolos':
                num_simb += 1

            # Cogemos un caracter aleatorio de ese tipo y lo añadimos
            nuevo_car = random.choice(caracteres[tipo_caracter])
            contraseña += nuevo_car

    return contraseña


# Mostramos el resultado final
print("Su nueva contraseña es: %s" % nueva_contraseña())
"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de funciones.
A continuación se creará una función que calcule conversiones de
divisa."""


# Creamos la función
def conversion(origen: str, destino: str, cantidad: float):
    """Esta función calcula la conversión de una cantidad de dinero de una
    determinada divisa a otra.
    @param origen: string
    @param destino: string
    @param cantidad: float
    @return: float"""

    # Diccionario con los cambios de divisa
    divisas = {'euro': {'yen': 123.91, 'dolar': 1.18, 'libra': 0.90},
               'yen': {'euro': 0.0081, 'dolar': 0.0096, 'libra': 0.0072},
               'dolar': {'euro': 0.84, 'yen': 104.69, 'libra': 0.76},
               'libra': {'euro': 1.11, 'dolar': 1.32, 'yen': 138.08}}

    # Calculamos el cambio
    param_cambio = divisas[origen][destino]
    cantidad_convertida = cantidad * param_cambio

    return cantidad_convertida


# Mostraamos el resultado
print(conversion('yen', 'dolar', 1000))
"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de definición de funciones.
A continuación se creará una función que simule la librería random."""


# Creamos la función
def aleatorio(num1, num2):
    """Esta función utiliza los métodos de la librería random para generar un
    número aleatorio entre dos números. Estos dos números serán los parámetros
    de la función.
    @param num1: entero o flotante
    @param num2: entero o flotante
    @return: entero o flotante"""

    # Importamos la librería random
    import random

    # Si uno de los números es flotante, utilizamos uniform.
    if isinstance(num1, float) or isinstance(num2, float):
        numero = random.uniform(num1, num2)

    # Si los dos son enteros, usamos randrange
    else:
        numero = random.randrange(num1, num2)

    return numero


# Mostramos el resultado
print(aleatorio(1, 10))
print(aleatorio(1, 2.5))
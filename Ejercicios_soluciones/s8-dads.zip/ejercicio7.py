"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de inicialización de
listas anidadas. A continuación se generará una lista
de cuatro listas. Cada una de ellas tendrá 4 números,
siendo el cuarto la suma de los anteriores."""

# Importamos random e iniciamos la lista
import random
n, matriz = random.randint(3, 20), []
for num in range(n):
    resultado = ''
    matriz.append([])
    for elemento in range(n - 1):
        matriz[num].append(random.randint(1, 10))
        resultado += str(matriz[num][elemento]) + " + "
    matriz[num].append(sum(matriz[num]))
    resultado = resultado[: -2] + "= " + str(matriz[num][-1])

    # Imprimimos el resultado
    print(resultado)
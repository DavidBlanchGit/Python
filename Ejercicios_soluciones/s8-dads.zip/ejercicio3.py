"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de inicialización de
diccionarios. A continuación se generará un diccionario
y se realizarán operaciones con él."""

# Este es el diccionario
juguetes = {
    'muñecas': 500,
    'juegos': ['Guess who?', 'Clue', 'Battleship'],
    'puzzles': ['Star Wars', 'Batman', 'Ironman']
}
print(juguetes)

# Añadir nueva clave
juguetes['peluches'] = ['oso', 'perro', 'gato']

# Eliminar elemento del valor de una clave
juguetes['puzzles'].remove('Batman')
print(juguetes)

# Añadir 100 al valor de muñecas
juguetes['muñecas'] += 100
print(juguetes)
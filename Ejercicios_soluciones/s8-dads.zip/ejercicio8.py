"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de inicialización de
listas anidadas. A continuación se generará una matriz
de 3 * 3 con números aleatorios no repetidos. Después
se ordenará."""

# Importamos random e iniciamos la lista
import random
matriz, ele_lista, lista_ordenada = [], [], []
for num in range(3):
    matriz.append([])
    for valor in range(3):
        elemento = random.randint(1, 30)
        while elemento in ele_lista:
            elemento = random.randint(1, 30)
        matriz[num].append(elemento)
        ele_lista.append(elemento)

# Ordenamos los elementos de la lista
while len(ele_lista) > 0:
    min = 31
    for elemento in ele_lista:
        if elemento <= min:
            min = elemento
    lista_ordenada.append(min)
    ele_lista.remove(min)

# Imprimimos resultado
cont1, cont2 = 0, 3
while cont1 < len(lista_ordenada):
    while cont2 > 0:
        print(lista_ordenada[cont1], end= "  ")
        cont1 += 1
        cont2 -= 1
    print('')
    cont2 = 3
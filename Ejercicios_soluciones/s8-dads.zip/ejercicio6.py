"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de inicialización de
listas anidadas. A continuación se generarán dos listas
con los valores de dos matrices. Después se verificará qué
elementos están en ambas matrices."""

# Iniciamos las listas
m1, m2= ["A"], ["B"]

# Pedimos datos sobre las matrices
for matriz in (m1, m2):
    filas = int(input("Introduce el número de filas de la matriz %s "
                      "y pulsa Enter: " % matriz[0]))
    columnas = int(input("Introduce el número de columnas de la matriz %s "
                         "y pulsa Enter: " % matriz[0]))
    for elemento_f in range(filas):
        matriz.append([])
        for elemento_c in range(columnas):
            elemento = int(input("Introduce el número de la posición %i, %i: "
                                 % (elemento_f, elemento_c)))
            matriz[elemento_f + 1].append(elemento)
    # Imprimimos el resultado
    print("La matriz %s es:" % matriz[0])
    del(matriz[0])
    matriz.append([])
    for fila in range(filas):
        for valor in matriz[fila]:
            print(valor, end= "  ")
            if valor not in matriz[-1]:
                matriz[-1].append(valor)
        print("")

# Numeros en común
for num in m1[-1]:
    if num in m2[-1]:
        print("El número %i se encuentra en ambas matrices." % num)
"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de inicialización de
diccionarios. A continuación se generará un diccionario
y se realizarán operaciones con él."""

# Con esto importamos el ejercicio1 para poder usarlo
import ejercicio1

# Creamos una lista con los 3 diccionarios y otra con las notas literales
alumnos = [ejercicio1.maria, ejercicio1.pedro, ejercicio1.miguel]
notas_literales = ["A", "B", "C", "D", "E", "F"]
notas_alumnos = []

# Cálculo de nota media
for alumno in range(len(alumnos)):
    for notas in ("ejerciciosSemanales", "pruebasSemanales"):
        alumnos[alumno][notas] = [alumnos[alumno][notas]]
        alumnos[alumno][notas].append(sum(alumnos[alumno][notas][0])
                                      / len(alumnos[alumno][notas][0]))

    # Cálculo de nota final
    alumnos[alumno]["nota"] = 0.1 * alumnos[alumno]["ejerciciosSemanales"][1] \
                              + 0.3 * alumnos[alumno]["pruebasSemanales"][1] \
                              + 0.6 * alumnos[alumno]["examen"]
    notas_alumnos.append(alumnos[alumno]["nota"])

    # Cálculo de nota literal mediante una variable de asignación
    v_asignacion = int(9.99 - alumnos[alumno]["nota"])
    if v_asignacion not in range(0, 6):
        alumnos[alumno]["notaLiteral"] = notas_literales[-1]
    else:
        alumnos[alumno]["notaLiteral"] = notas_literales[v_asignacion]

    # Imprimir cada dato de cada alumno
    for dato in alumnos[alumno]:
        print(dato, ":", alumnos[alumno][dato])
    print("\n")

# Cálculo de nota media de los alumnos
print("Nota media de los alumnos : %.2f" % (sum(notas_alumnos)
                                            / len(notas_alumnos)))
"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de inicialización de
diccionarios. A continuación se generará un diccionario
con los meses y dias del año y se calculará si es bisiesto
o no."""

# Inicialización de los diccionarios
calendario = {'enero': 31, 'febrero': 28, 'marzo': 31,
              'abril': 30, 'mayo': 31, 'junio': 30,
              'julio': 31, 'agosto': 31, 'septiembre': 30,
              'octubre': 31, 'noviembre': 30, 'diciembre': 31}
fecha = {'dia': 0, 'mes': '', 'año': 0, 'bisiesto': 'no bisiesto'}

# Pedir datos al usuario y cálculo de año bisiesto
fecha['año'] = int(input("Introduce el año: "))
if fecha['año'] % 4 == 0:
    if fecha['año'] % 100 == 0:
        if fecha['año'] % 400 == 0:
            fecha['bisiesto'] = 'bisiesto'
    else:
        fecha['bisiesto'] = 'bisiesto'
if fecha['bisiesto'] == 'bisiesto':
    calendario['febrero'] += 1
while fecha['dia'] not in range(1, 32):
    fecha['dia'] = int(input("Introduce el día: "))
while fecha['mes'] not in calendario:
    fecha['mes'] = input("Introduce el mes: ").lower()
while fecha['dia'] > calendario[fecha['mes']]:
    print("El mes %s no tiene %i días." % (fecha['mes'], fecha['dia']))
    fecha['dia'] = int(input("Introduce un día válido: "))

# Resultado final
print("%i de %s de %i, año %s." % (fecha['dia'], fecha['mes'],
                                   fecha['año'], fecha['bisiesto']))
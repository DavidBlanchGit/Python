"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de inicialización de
diccionarios. A continuación se generará un diccionario
con precios y después se imprimirán por pantalla."""

# Creamos el diccionario con los precios
precios = {"Manzana": 5.5, "Melón": 6, "Banana": 7.2, "Naranja": 4}

# Imprimimos los precios
for producto in precios:
    print("%s : %.2f" % (producto, precios[producto]))
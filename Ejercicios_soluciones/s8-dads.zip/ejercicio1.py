"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de inicialización de
diccionarios. A continuación se generarán tres diccionarios
con tres claves y se generarán valores aleatorios."""

# Importamos la librería random
import random

# Iniciamos los diccionarios de cada uno de  los alumnos
maria = {"nombre": "María", "ejerciciosSemanales": [], "pruebasSemanales": []}
pedro = {"nombre": "Pedro", "ejerciciosSemanales": [], "pruebasSemanales": []}
miguel = {"nombre": "Miguel", "ejerciciosSemanales": [], "pruebasSemanales": []}
print(maria, "\n", pedro, "\n", miguel)

# Asignamos notas de exámenes a cada clave
for diccionario in (maria, pedro, miguel):
    for notas in ("ejerciciosSemanales", "pruebasSemanales"):
        for n in range(10):
            num = random.randint(0, 10)
            diccionario[notas].append(num)
    # Creamos una nueva clave y asignamos un valor aleatorio
    diccionario["examen"] = random.randint(0, 10)

print(maria, "\n", pedro, "\n", miguel)
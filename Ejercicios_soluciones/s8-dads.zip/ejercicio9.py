"""Autor : Daniel Alonso
Fecha : 22/10/2020
Python version : 3.8
Descripción : Este es un programa de inicialización de
listas. A continuación se generarán listas con pedidos
y comprobará si hay stock en la tienda."""

# Importamos random e iniciamos la variable almacenaado
import random
almacenado = []
for num in range(10):
    almacenado.append(random.randrange(0, 10))
print(almacenado)

# Mostramos por pantalla los productos almacenados
print("Almacenados:", end=" ")
for num in range(1, 11):
    print("tamaño%i" % num, end=" ")
print("\n             ", end="")
for elemento in almacenado:
    print(elemento, end="       ")
print("")

# Pedimos número de clientes e iniciamos sus pedidos
pedidos = []
clientes = int(input("Introduce el número de clientes: "))
print("Pedidos originales")
for cliente in range(clientes):
    pedidos.append([])
    print("Cliente %i:" % (cliente + 1), end="   ")
    for num in range(10):
        cantidad = random.randint(0, 4)
        pedidos[cliente].append(cantidad)
        print(cantidad, end="       ")
    print("")

# Cálculo de pedidos pendientes
print("\nPedidos pendientes")
for cliente in range(clientes):
    for elemento in range(len(almacenado)):
        if almacenado[elemento] >= pedidos[cliente][elemento]:
            almacenado[elemento] -= pedidos[cliente][elemento]
            pedidos[cliente][elemento] = 0
        else:
            pedidos[cliente][elemento] -= almacenado[elemento]
            almacenado[elemento] = 0

# Imprimimos los pedidos pendientes
for cliente in range(clientes):
    if sum(pedidos[cliente]) != 0:
        print("Cliente %i:" % (cliente + 1), end="   ")
        for elemento in pedidos[cliente]:
            print(elemento, end="       ")
        print("")